Graphic Equalizer + Bass Boost + Treble + Crystalliser + Surround + Reverb (ReverbPresets64.dll)

الطريقة 1 - بناء الـ exe اونلاين بدون تثبيت شي (GitHub):
  1) سوّ حساب على github.com ثم New repository
  2) ارفع كل محتويات هذا المجلد (Add file > Upload files)  [لازم يشمل مجلد .github]
  3) اضغط تبويب Actions > build-exe > ينتظر دقيقة
  4) افتح اخر تشغيل ونزّل الملف ReverbEQ (zip) من Artifacts: فيه ReverbEQ.exe + الـ DLL

الطريقة 2 - على جهازك: شغّل build.bat (يحتاج MinGW-w64 او Visual Studio x64)

التشغيل: ReverbEQ.exe  ثم OPEN او اسحب ملف WAV على النافذة. (الـ DLL بنفس المجلد)
Space = Play/Stop | FX = Reverb on/off | EDIT = واجهة الـ Reverb | Presets = من الـ DLL
Bass Boost / Treble / Crystalliser / Surround = السلايدرات الافقية
Double-click على اي سلايدر = صفر | عجلة الماوس تغيّر القيمة
