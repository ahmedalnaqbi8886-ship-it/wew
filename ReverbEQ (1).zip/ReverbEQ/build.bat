@echo off
where g++ >nul 2>nul
if %errorlevel%==0 (
  g++ -O2 -std=c++17 -static -mwindows main.cpp -o ReverbEQ.exe -lgdi32 -luser32 -lwinmm -lcomdlg32 -lshell32 -lmsimg32
  goto done
)
where cl >nul 2>nul
if %errorlevel%==0 (
  cl /nologo /O2 /EHsc /utf-8 /std:c++17 main.cpp /Fe:ReverbEQ.exe user32.lib gdi32.lib winmm.lib comdlg32.lib shell32.lib msimg32.lib /link /SUBSYSTEM:WINDOWS
  goto done
)
echo ما لقيت g++ ولا cl.
:done
