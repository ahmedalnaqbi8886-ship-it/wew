// dsp.h - منطق الصوت فقط (بدون Windows): الإيكولايزر 7 نطاقات + قارئ WAV
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

struct Biquad {
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    float z1[2] = {0, 0}, z2[2] = {0, 0};
};

struct EQ {
    static const int N = 7;
    float freq[N] = {125, 250, 500, 1000, 2000, 4000, 8000};
    float gainDb[N] = {0, 0, 0, 0, 0, 0, 0};
    float fs = 48000.f;
    float Q = 1.2f;
    Biquad b[N];

    // معاملات RBJ peaking
    void update() {
        for (int i = 0; i < N; i++) {
            Biquad& q = b[i];
            float A = powf(10.f, gainDb[i] / 40.f);
            float w = 2.f * 3.14159265358979f * freq[i] / fs;
            float alpha = sinf(w) / (2.f * Q);
            float cw = cosf(w);
            float a0 = 1.f + alpha / A;
            q.b0 = (1.f + alpha * A) / a0;
            q.b1 = (-2.f * cw) / a0;
            q.b2 = (1.f - alpha * A) / a0;
            q.a1 = (-2.f * cw) / a0;
            q.a2 = (1.f - alpha / A) / a0;
        }
    }
    void setRate(float r) { fs = r; update(); }

    // inter = صوت ستيريو متداخل L R L R ...
    void process(float* inter, int frames) {
        for (int i = 0; i < N; i++) {
            if (fabsf(gainDb[i]) < 0.01f) continue;
            Biquad& q = b[i];
            for (int c = 0; c < 2; c++) {
                float z1 = q.z1[c], z2 = q.z2[c];
                for (int n = 0; n < frames; n++) {
                    float x = inter[n * 2 + c];
                    float y = q.b0 * x + z1;
                    z1 = q.b1 * x - q.a1 * y + z2;
                    z2 = q.b2 * x - q.a2 * y;
                    inter[n * 2 + c] = y;
                }
                q.z1[c] = z1;
                q.z2[c] = z2;
            }
        }
    }
};

static inline uint16_t rd16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static inline uint32_t rd32(const uint8_t* p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

// يحوّل ملف WAV إلى ستيريو float متداخل. يرجّع false لو الصيغة غير مدعومة.
static inline bool parseWav(const std::vector<uint8_t>& d, std::vector<float>& out, int& rate) {
    out.clear();
    if (d.size() < 44 || memcmp(d.data(), "RIFF", 4) || memcmp(d.data() + 8, "WAVE", 4)) return false;
    size_t p = 12;
    int tag = 0, ch = 0, bits = 0;
    rate = 0;
    const uint8_t* data = nullptr;
    size_t dataLen = 0;
    while (p + 8 <= d.size()) {
        uint32_t len = rd32(&d[p + 4]);
        const uint8_t* c = &d[p + 8];
        size_t avail = d.size() - (p + 8);
        if (!memcmp(&d[p], "fmt ", 4) && len >= 16 && avail >= 16) {
            tag = rd16(c);
            ch = rd16(c + 2);
            rate = (int)rd32(c + 4);
            bits = rd16(c + 14);
            if (tag == 0xFFFE && len >= 26 && avail >= 26) tag = rd16(c + 24);
        } else if (!memcmp(&d[p], "data", 4)) {
            data = c;
            dataLen = len > avail ? avail : len;
            break;
        }
        p += 8 + (size_t)len + (len & 1);
    }
    if (!data || ch < 1 || rate < 8000) return false;
    int bps = bits / 8;
    if (bps < 1) return false;
    bool isFloat = (tag == 3);
    if (!(tag == 1 || isFloat)) return false;
    if (isFloat && bps != 4 && bps != 8) return false;
    if (!isFloat && (bps < 1 || bps > 4)) return false;
    size_t frames = dataLen / ((size_t)bps * ch);
    out.resize(frames * 2);
    for (size_t i = 0; i < frames; i++) {
        float v[2];
        for (int c = 0; c < 2; c++) {
            int cc = (c < ch) ? c : 0;
            const uint8_t* s = data + (i * ch + cc) * bps;
            float x;
            if (isFloat) {
                if (bps == 4) { float f; memcpy(&f, s, 4); x = f; }
                else { double f; memcpy(&f, s, 8); x = (float)f; }
            } else if (bps == 1) x = ((int)s[0] - 128) / 128.f;
            else if (bps == 2) x = (int16_t)rd16(s) / 32768.f;
            else if (bps == 3) { int32_t t = (int32_t)(((uint32_t)s[0] << 8) | ((uint32_t)s[1] << 16) | ((uint32_t)s[2] << 24)); x = t / 2147483648.f; }
            else x = (int32_t)rd32(s) / 2147483648.f;
            v[c] = x;
        }
        out[i * 2] = v[0];
        out[i * 2 + 1] = v[1];
    }
    return true;
}

// ---------------------------------------------------------------- تأثيرات إضافية
static inline void runBiquad(Biquad& q, float* inter, int frames) {
    for (int c = 0; c < 2; c++) {
        float z1 = q.z1[c], z2 = q.z2[c];
        for (int n = 0; n < frames; n++) {
            float x = inter[n * 2 + c];
            float y = q.b0 * x + z1;
            z1 = q.b1 * x - q.a1 * y + z2;
            z2 = q.b2 * x - q.a2 * y;
            inter[n * 2 + c] = y;
        }
        q.z1[c] = z1;
        q.z2[c] = z2;
    }
}

// Bass Boost / Treble / Crystalliser / Surround  (كل قيمة 0..100)
struct Effects {
    float bass = 0, treble = 0, crystal = 0, surround = 0;
    float fs = 48000.f;
    Biquad bs, ts;
    float lp[2] = {0, 0};
    float lpA = 0.f;

    static void shelf(Biquad& q, bool high, float f0, float dB, float fs) {
        float A = powf(10.f, dB / 40.f);
        float w = 2.f * 3.14159265358979f * f0 / fs;
        float cw = cosf(w), alpha = sinf(w) / 2.f * 1.41421356f, sA = 2.f * sqrtf(A) * alpha;
        float b0, b1, b2, a0, a1, a2;
        if (!high) {
            b0 = A * ((A + 1) - (A - 1) * cw + sA); b1 = 2 * A * ((A - 1) - (A + 1) * cw); b2 = A * ((A + 1) - (A - 1) * cw - sA);
            a0 = (A + 1) + (A - 1) * cw + sA;       a1 = -2 * ((A - 1) + (A + 1) * cw);    a2 = (A + 1) + (A - 1) * cw - sA;
        } else {
            b0 = A * ((A + 1) + (A - 1) * cw + sA); b1 = -2 * A * ((A - 1) + (A + 1) * cw); b2 = A * ((A + 1) + (A - 1) * cw - sA);
            a0 = (A + 1) - (A - 1) * cw + sA;       a1 = 2 * ((A - 1) - (A + 1) * cw);      a2 = (A + 1) - (A - 1) * cw - sA;
        }
        q.b0 = b0 / a0; q.b1 = b1 / a0; q.b2 = b2 / a0; q.a1 = a1 / a0; q.a2 = a2 / a0;
    }
    void update() {
        shelf(bs, false, 100.f, bass * 0.14f, fs);      // حتى +14dB
        shelf(ts, true, 6500.f, treble * 0.12f, fs);    // حتى +12dB
        lpA = expf(-2.f * 3.14159265358979f * 3000.f / fs);
    }
    void setRate(float r) { fs = r; update(); }

    void process(float* x, int frames) {
        if (bass > 0.5f) runBiquad(bs, x, frames);
        if (treble > 0.5f) runBiquad(ts, x, frames);
        if (crystal > 0.5f) {   // exciter: نأخذ الترددات العالية، نعمل لها تشويه خفيف ونضيفها
            float amt = crystal * 0.01f * 0.6f;
            for (int n = 0; n < frames; n++)
                for (int c = 0; c < 2; c++) {
                    float s = x[n * 2 + c];
                    lp[c] = (1.f - lpA) * s + lpA * lp[c];
                    float hi = s - lp[c];
                    x[n * 2 + c] = s + amt * tanhf(hi * 4.f);
                }
        }
        if (surround > 0.5f) {  // توسيع الستيريو (mid/side)
            float k = 1.f + surround * 0.01f * 1.5f;
            for (int n = 0; n < frames; n++) {
                float m = 0.5f * (x[n * 2] + x[n * 2 + 1]), s = 0.5f * (x[n * 2] - x[n * 2 + 1]) * k;
                x[n * 2] = m + s; x[n * 2 + 1] = m - s;
            }
        }
    }
};
