// Graphic Equalizer + ReverbPresets64.dll (VST2) host
// Win32 + winmm فقط - بدون مكتبات خارجية. ويندوز 64-بت.
#define UNICODE
#define _UNICODE
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <commdlg.h>
#include <shellapi.h>
#include <atomic>
#include <cstdio>
#include <string>
#include <vector>
#include "dsp.h"

#ifdef _MSC_VER
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "msimg32.lib")
#endif

// ============================================================ VST2 (واجهة مختصرة بدون SDK)
struct AEffect;
typedef intptr_t (*HostCb)(AEffect*, int32_t, int32_t, intptr_t, void*, float);
typedef intptr_t (*DispatchFn)(AEffect*, int32_t, int32_t, intptr_t, void*, float);
typedef void (*ProcFn)(AEffect*, float**, float**, int32_t);
typedef void (*SetParamFn)(AEffect*, int32_t, float);
typedef float (*GetParamFn)(AEffect*, int32_t);
struct AEffect {
    int32_t magic;
    DispatchFn dispatcher;
    ProcFn process;
    SetParamFn setParameter;
    GetParamFn getParameter;
    int32_t numPrograms, numParams, numInputs, numOutputs, flags;
    intptr_t resvd1, resvd2;
    int32_t initialDelay, realQualities, offQualities;
    float ioRatio;
    void* object;
    void* user;
    int32_t uniqueID, version;
    ProcFn processReplacing;
    void* processDoubleReplacing;
    char future[56];
};
struct ERect { int16_t top, left, bottom, right; };
struct VstTimeInfo {
    double samplePos, sampleRate, nanoSeconds, ppqPos, tempo, barStartPos, cycleStartPos, cycleEndPos;
    int32_t timeSigNumerator, timeSigDenominator, smpteOffset, smpteFrameRate, samplesToNextClock, flags;
};
enum {
    effOpen = 0, effClose = 1, effSetProgram = 2, effGetProgram = 3, effGetProgramName = 5,
    effSetSampleRate = 10, effSetBlockSize = 11, effMainsChanged = 12, effEditGetRect = 13,
    effEditOpen = 14, effEditClose = 15, effEditIdle = 19, effGetProgramNameIndexed = 29,
    effGetEffectName = 45, effStartProcess = 71, effStopProcess = 72
};
static const int FR = 1024;  // حجم البلوك

// ============================================================ الحالة العامة
struct App {
    HWND wnd = 0, edWnd = 0;
    HINSTANCE inst = 0;
    // EQ
    EQ eq;
    Effects fxs;   // Bass / Treble / Crystalliser / Surround (0..100)
    float levelDb = 0;
    bool eqOn = true;
    // VST
    HMODULE vstMod = 0;
    AEffect* fx = 0;
    bool fxOn = false;
    std::vector<std::wstring> progs;
    std::wstring vstError;
    // صوت
    std::vector<float> pcm;
    size_t pos = 0;
    int rate = 48000;
    bool playing = false;
    std::wstring fileName;
    CRITICAL_SECTION cs;
    // واجهة
    int drag = 0;          // 0 لا شي، 1..7 نطاق، 10 level
    std::wstring status;
} G;

static VstTimeInfo g_ti;

static intptr_t hostCb(AEffect*, int32_t op, int32_t idx, intptr_t val, void* ptr, float) {
    switch (op) {
    case 1: return 2400;                       // audioMasterVersion
    case 7:                                    // GetTime
        memset(&g_ti, 0, sizeof g_ti);
        g_ti.sampleRate = G.rate; g_ti.tempo = 120; g_ti.timeSigNumerator = 4; g_ti.timeSigDenominator = 4;
        g_ti.flags = (1 << 1) | (1 << 10) | (1 << 13);  // playing | tempo valid | timesig valid
        return (intptr_t)&g_ti;
    case 15:                                   // SizeWindow
        if (G.edWnd) {
            RECT r = {0, 0, idx, (int)val};
            AdjustWindowRect(&r, WS_CAPTION | WS_SYSMENU, FALSE);
            SetWindowPos(G.edWnd, 0, 0, 0, r.right - r.left, r.bottom - r.top, SWP_NOMOVE | SWP_NOZORDER);
        }
        return 1;
    case 16: return G.rate;                    // GetSampleRate
    case 17: return FR;                        // GetBlockSize
    case 23: return 2;                         // realtime
    case 32: case 33: if (ptr) strcpy((char*)ptr, "EQ Host"); return 1;
    case 34: return 1000;
    case 37: return (ptr && !strcmp((const char*)ptr, "sizeWindow")) ? 1 : 0;
    case 38: return 1;
    default: return 0;
    }
}

static std::wstring exeDir() {
    wchar_t p[MAX_PATH];
    GetModuleFileNameW(0, p, MAX_PATH);
    std::wstring s = p;
    return s.substr(0, s.find_last_of(L"\\/") + 1);
}

static std::wstring ansiToW(const char* s) {
    wchar_t w[512];
    int n = MultiByteToWideChar(CP_ACP, 0, s, -1, w, 512);
    return n > 0 ? std::wstring(w) : std::wstring();
}

static bool vstLoad(const std::wstring& path) {
    G.vstMod = LoadLibraryW(path.c_str());
    if (!G.vstMod) { G.vstError = L"ما قدرت أحمّل الـ DLL (تأكد انه 64-بت وبجنب البرنامج)"; return false; }
    typedef AEffect* (*Entry)(HostCb);
    Entry e = (Entry)GetProcAddress(G.vstMod, "VSTPluginMain");
    if (!e) e = (Entry)GetProcAddress(G.vstMod, "main");
    if (!e) { G.vstError = L"الـ DLL ما فيها VSTPluginMain"; return false; }
    G.fx = e(hostCb);
    if (!G.fx || G.fx->magic != 0x56737450) { G.fx = 0; G.vstError = L"الـ DLL مو VST2 صالح"; return false; }
    G.fx->dispatcher(G.fx, effOpen, 0, 0, 0, 0);
    G.fx->dispatcher(G.fx, effSetSampleRate, 0, 0, 0, (float)G.rate);
    G.fx->dispatcher(G.fx, effSetBlockSize, 0, FR, 0, 0);
    G.fx->dispatcher(G.fx, effMainsChanged, 0, 1, 0, 0);
    G.fx->dispatcher(G.fx, effStartProcess, 0, 0, 0, 0);
    // أسماء الـ presets
    int n = G.fx->numPrograms; if (n > 256) n = 256;
    int cur = (int)G.fx->dispatcher(G.fx, effGetProgram, 0, 0, 0, 0);
    for (int i = 0; i < n; i++) {
        char buf[256] = {0};
        if (!G.fx->dispatcher(G.fx, effGetProgramNameIndexed, i, 0, buf, 0) || !buf[0]) {
            G.fx->dispatcher(G.fx, effSetProgram, 0, i, 0, 0);
            G.fx->dispatcher(G.fx, effGetProgramName, 0, 0, buf, 0);
        }
        wchar_t d[32]; swprintf(d, 32, L"Preset %d", i + 1);
        G.progs.push_back(buf[0] ? ansiToW(buf) : std::wstring(d));
    }
    if (n > 0) G.fx->dispatcher(G.fx, effSetProgram, 0, cur < n ? cur : 0, 0, 0);
    G.fxOn = true;
    return true;
}

static void vstSetRate(int r) {
    if (!G.fx) return;
    G.fx->dispatcher(G.fx, effMainsChanged, 0, 0, 0, 0);
    G.fx->dispatcher(G.fx, effSetSampleRate, 0, 0, 0, (float)r);
    G.fx->dispatcher(G.fx, effMainsChanged, 0, 1, 0, 0);
}

static void vstProcess(float* inter, int frames) {
    AEffect* f = G.fx;
    if (!f || f->numInputs <= 0 || f->numOutputs <= 0) return;
    static float inB[8][FR], outB[8][FR];
    float* in[8]; float* out[8];
    for (int c = 0; c < 8; c++) { in[c] = inB[c]; out[c] = outB[c]; memset(inB[c], 0, sizeof(float) * FR); memset(outB[c], 0, sizeof(float) * FR); }
    for (int n = 0; n < frames; n++) { inB[0][n] = inter[n * 2]; inB[1][n] = inter[n * 2 + 1]; }
    int ni = f->numInputs > 8 ? 8 : f->numInputs, no = f->numOutputs > 8 ? 8 : f->numOutputs;
    if (ni == 1) { /* مونو: L+R */ for (int n = 0; n < frames; n++) inB[0][n] = 0.5f * (inB[0][n] + inB[1][n]); }
    (void)ni; (void)no;
    if (f->flags & 16) f->processReplacing(f, in, out, frames);
    else f->process(f, in, out, frames);  // قديم (accumulate)
    for (int n = 0; n < frames; n++) {
        inter[n * 2] = outB[0][n];
        inter[n * 2 + 1] = (f->numOutputs >= 2) ? outB[1][n] : outB[0][n];
    }
}

// ============================================================ المحرك الصوتي (waveOut)
struct Audio {
    HWAVEOUT h = 0;
    HANDLE evt = 0, thread = 0;
    WAVEHDR hdr[4];
    short buf[4][FR * 2];
    std::atomic<bool> run{false};
} A;

static void render(short* out) {
    float t[FR * 2];
    EnterCriticalSection(&G.cs);
    size_t total = G.pcm.size() / 2;
    if (G.playing && total > 0) {
        int n = 0;
        while (n < FR) {
            if (G.pos >= total) G.pos = 0;
            size_t take = total - G.pos; if (take > (size_t)(FR - n)) take = FR - n;
            memcpy(&t[n * 2], &G.pcm[G.pos * 2], take * 2 * sizeof(float));
            G.pos += take; n += (int)take;
        }
    } else memset(t, 0, sizeof t);
    G.fxs.process(t, FR);
    if (G.eqOn) G.eq.process(t, FR);
    if (G.fxOn && G.fx) vstProcess(t, FR);
    float g = powf(10.f, G.levelDb / 20.f);
    LeaveCriticalSection(&G.cs);
    for (int i = 0; i < FR * 2; i++) {
        float v = t[i] * g;
        if (v > 1.f) v = 1.f; else if (v < -1.f) v = -1.f;
        out[i] = (short)lrintf(v * 32767.f);
    }
}

static DWORD WINAPI audioThread(LPVOID) {
    while (A.run) {
        WaitForSingleObject(A.evt, 100);
        for (int i = 0; i < 4 && A.run; i++) {
            if (A.hdr[i].dwFlags & WHDR_DONE) {
                render(A.buf[i]);
                waveOutWrite(A.h, &A.hdr[i], sizeof(WAVEHDR));
            }
        }
    }
    return 0;
}

static void audioStop() {
    if (!A.h) return;
    A.run = false;
    SetEvent(A.evt);
    WaitForSingleObject(A.thread, 2000);
    CloseHandle(A.thread); A.thread = 0;
    waveOutReset(A.h);
    for (int i = 0; i < 4; i++) waveOutUnprepareHeader(A.h, &A.hdr[i], sizeof(WAVEHDR));
    waveOutClose(A.h); A.h = 0;
    CloseHandle(A.evt); A.evt = 0;
}

static bool audioStart(int rate) {
    audioStop();
    WAVEFORMATEX w = {};
    w.wFormatTag = WAVE_FORMAT_PCM; w.nChannels = 2; w.nSamplesPerSec = rate; w.wBitsPerSample = 16;
    w.nBlockAlign = 4; w.nAvgBytesPerSec = rate * 4;
    A.evt = CreateEventW(0, FALSE, FALSE, 0);
    if (waveOutOpen(&A.h, WAVE_MAPPER, &w, (DWORD_PTR)A.evt, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) { A.h = 0; CloseHandle(A.evt); A.evt = 0; return false; }
    EnterCriticalSection(&G.cs);
    G.rate = rate;
    G.eq.setRate((float)rate);
    G.fxs.setRate((float)rate);
    vstSetRate(rate);
    LeaveCriticalSection(&G.cs);
    A.run = true;
    for (int i = 0; i < 4; i++) {
        memset(&A.hdr[i], 0, sizeof(WAVEHDR));
        A.hdr[i].lpData = (LPSTR)A.buf[i];
        A.hdr[i].dwBufferLength = FR * 4;
        waveOutPrepareHeader(A.h, &A.hdr[i], sizeof(WAVEHDR));
        render(A.buf[i]);
        waveOutWrite(A.h, &A.hdr[i], sizeof(WAVEHDR));
    }
    A.thread = CreateThread(0, 0, audioThread, 0, 0, 0);
    return true;
}

static bool openAudioFile(const std::wstring& path) {
    FILE* f = _wfopen(path.c_str(), L"rb");
    if (!f) { G.status = L"ما قدرت أفتح الملف"; return false; }
    std::vector<uint8_t> d;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    if (n > 0) { d.resize(n); if (fread(d.data(), 1, n, f) != (size_t)n) d.clear(); }
    fclose(f);
    std::vector<float> pcm; int rate = 0;
    if (!parseWav(d, pcm, rate)) { G.status = L"الملف لازم يكون WAV (PCM / float)"; return false; }
    EnterCriticalSection(&G.cs);
    G.pcm.swap(pcm); G.pos = 0; G.playing = true;
    LeaveCriticalSection(&G.cs);
    size_t k = path.find_last_of(L"\\/");
    G.fileName = (k == std::wstring::npos) ? path : path.substr(k + 1);
    if (!A.h || rate != G.rate) {
        if (!audioStart(rate)) { G.status = L"ما قدرت أفتح كرت الصوت"; return false; }
    }
    G.status = L"";
    return true;
}

static void pickFile() {
    wchar_t buf[MAX_PATH] = L"";
    OPENFILENAMEW o = {};
    o.lStructSize = sizeof o; o.hwndOwner = G.wnd;
    o.lpstrFilter = L"WAV audio (*.wav)\0*.wav\0\0";
    o.lpstrFile = buf; o.nMaxFile = MAX_PATH;
    o.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameW(&o)) openAudioFile(buf);
}

// ============================================================ محرر الـ VST
static LRESULT CALLBACK edProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_CLOSE) {
        if (G.fx) G.fx->dispatcher(G.fx, effEditClose, 0, 0, 0, 0);
        DestroyWindow(h); G.edWnd = 0; return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

static void openEditor() {
    if (!G.fx || !(G.fx->flags & 1)) { G.status = L"الـ plugin ما عنده واجهة"; return; }
    if (G.edWnd) { SetForegroundWindow(G.edWnd); return; }
    ERect* r = 0;
    G.fx->dispatcher(G.fx, effEditGetRect, 0, 0, &r, 0);
    int w = r ? r->right - r->left : 400, h = r ? r->bottom - r->top : 300;
    RECT rc = {0, 0, w, h};
    AdjustWindowRect(&rc, WS_CAPTION | WS_SYSMENU, FALSE);
    G.edWnd = CreateWindowExW(0, L"RevHostEditor", L"Reverb", WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                              CW_USEDEFAULT, CW_USEDEFAULT, rc.right - rc.left, rc.bottom - rc.top, G.wnd, 0, G.inst, 0);
    G.fx->dispatcher(G.fx, effEditOpen, 0, 0, G.edWnd, 0);
}

// ============================================================ الرسم
static const int W = 493, H = 382, BY = 354;  // BY = بداية الشريط السفلي
static const int BOX_Y = 104, BOX_H = 166, BOX_W = 30;
static inline int bandX(int i) { return 62 + 46 * i; }
static inline int dbToY(float db) { return (int)lrintf(181.f - db * 55.f / 12.f); }
static inline float yToDb(int y) { float d = (181.f - y) * 12.f / 55.f; return d > 12 ? 12 : (d < -12 ? -12 : d); }
static inline int lvToY(float db) { return (int)lrintf(124.f - db * 104.f / 24.f); }
static inline float yToLv(int y) { float d = -(y - 124.f) * 24.f / 104.f; return d > 0 ? 0 : (d < -24 ? -24 : d); }

static const int FXW = 120;
static inline int fxX(int i) { return (i % 2 == 0) ? 92 : 332; }
static inline int fxY(int i) { return i < 2 ? 306 : 334; }
struct Btn { int id; RECT r; };
enum { H_CHECK = 20, H_PRESET, H_DEV, H_HELP, H_MENU, H_SAVE, H_DEL, H_DEFAULT, H_OPEN, H_PLAY, H_FX, H_EDIT };
static Btn g_btn[] = {
    {H_CHECK, {8, 68, 130, 88}},   {H_PRESET, {262, 68, 417, 88}}, {H_DEV, {197, 8, 367, 28}},
    {H_HELP, {373, 8, 410, 28}},   {H_MENU, {410, 8, 426, 28}},    {H_SAVE, {425, 66, 449, 90}},
    {H_DEL, {466, 66, 488, 90}},   {H_DEFAULT, {22, BY + 4, 108, BY + 22}},
    {H_OPEN, {118, BY + 3, 142, BY + 25}}, {H_PLAY, {148, BY + 3, 172, BY + 25}}, {H_FX, {180, BY + 3, 204, BY + 25}}, {H_EDIT, {213, BY + 3, 237, BY + 25}},
};

static void gradV(HDC dc, int x, int y, int w, int h, COLORREF a, COLORREF b) {
    TRIVERTEX v[2] = {
        {x, y, (COLOR16)(GetRValue(a) << 8), (COLOR16)(GetGValue(a) << 8), (COLOR16)(GetBValue(a) << 8), 0},
        {x + w, y + h, (COLOR16)(GetRValue(b) << 8), (COLOR16)(GetGValue(b) << 8), (COLOR16)(GetBValue(b) << 8), 0}};
    GRADIENT_RECT gr = {0, 1};
    GradientFill(dc, v, 2, &gr, 1, GRADIENT_FILL_RECT_V);
}
static void box(HDC dc, int x, int y, int w, int h, COLORREF c) {
    RECT r = {x, y, x + w, y + h}; HBRUSH b = CreateSolidBrush(c); FillRect(dc, &r, b); DeleteObject(b);
}
static void rrect(HDC dc, int x, int y, int w, int h, int rad, COLORREF fill, COLORREF border) {
    HBRUSH b = CreateSolidBrush(fill); HPEN p = CreatePen(PS_SOLID, 1, border);
    HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, p);
    RoundRect(dc, x, y, x + w + 1, y + h + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(b); DeleteObject(p);
}
static void line(HDC dc, int x1, int y1, int x2, int y2, COLORREF c, int wd = 1) {
    HPEN p = CreatePen(PS_SOLID, wd, c); HGDIOBJ op = SelectObject(dc, p);
    MoveToEx(dc, x1, y1, 0); LineTo(dc, x2, y2); SelectObject(dc, op); DeleteObject(p);
}
static void tri(HDC dc, POINT a, POINT b, POINT c, COLORREF col) {
    HBRUSH br = CreateSolidBrush(col); HPEN p = CreatePen(PS_SOLID, 1, col);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, p);
    POINT pts[3] = {a, b, c}; Polygon(dc, pts, 3);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(br); DeleteObject(p);
}
static void txt(HDC dc, const std::wstring& s, int x, int y, int w, int h, UINT fmt, COLORREF c) {
    RECT r = {x, y, x + w, y + h}; SetTextColor(dc, c);
    DrawTextW(dc, s.c_str(), -1, &r, fmt | DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX);
}

static HFONT mkFont(int h, bool bold) {
    return CreateFontW(-h, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Tahoma");
}

static void combo(HDC dc, int x, int y, int w, int h, const std::wstring& s, HFONT f) {
    rrect(dc, x, y, w, h, 4, RGB(255, 255, 255), RGB(122, 133, 148));
    SelectObject(dc, f);
    txt(dc, s, x + 6, y, w - 26, h, DT_LEFT | DT_END_ELLIPSIS, RGB(0, 0, 0));
    gradV(dc, x + w - 17, y + 2, 15, h - 3, RGB(236, 241, 248), RGB(196, 207, 224));
    tri(dc, {x + w - 13, y + h / 2 - 2}, {x + w - 5, y + h / 2 - 2}, {x + w - 9, y + h / 2 + 3}, RGB(30, 40, 60));
}

static void thumb(HDC dc, int cx, int cy) {
    rrect(dc, cx - 12, cy - 7, 24, 14, 5, RGB(214, 214, 214), RGB(95, 95, 95));
    gradV(dc, cx - 10, cy - 5, 21, 6, RGB(250, 250, 250), RGB(214, 214, 214));
    box(dc, cx - 11, cy - 1, 23, 3, RGB(44, 118, 226));
    line(dc, cx - 11, cy - 2, cx + 11, cy - 2, RGB(140, 190, 250));
}

static void paint(HDC dc) {
    HFONT f9 = mkFont(11, false), f9b = mkFont(11, true), f13b = mkFont(14, true), f18 = mkFont(18, true);
    SetBkMode(dc, TRANSPARENT);
    // خلفية + الهيدر
    box(dc, 0, 0, W, H, RGB(240, 240, 240));
    gradV(dc, 0, 0, W, 36, RGB(255, 255, 255), RGB(226, 232, 240));
    line(dc, 0, 36, W, 36, RGB(160, 170, 185));
    rrect(dc, 11, 5, 27, 27, 5, RGB(255, 255, 255), RGB(120, 130, 150));
    for (int i = 0; i < 4; i++) box(dc, 16 + i * 5, 10 + (i % 2) * 4, 2, 17 - (i % 2) * 4, RGB(50, 110, 200));
    SelectObject(dc, f13b); txt(dc, L"Graphic Equalizer", 46, 5, 150, 26, DT_LEFT, RGB(0, 0, 0));
    std::wstring dev = G.fileName.empty() ? L"Open audio file..." : G.fileName;
    combo(dc, 197, 8, 170, 20, dev, f9);
    rrect(dc, 373, 8, 36, 20, 5, RGB(240, 244, 250), RGB(110, 125, 150));
    SelectObject(dc, f9b); txt(dc, L"?", 373, 8, 36, 20, DT_CENTER, RGB(25, 90, 190));
    rrect(dc, 410, 8, 16, 20, 5, RGB(240, 244, 250), RGB(110, 125, 150));
    tri(dc, {414, 16}, {422, 16}, {418, 21}, RGB(25, 90, 190));
    // شريط Equalizer
    gradV(dc, 0, 37, W, 22, RGB(250, 250, 250), RGB(236, 236, 236));
    SelectObject(dc, f9); txt(dc, L"Equalizer", 0, 37, W, 22, DT_CENTER, RGB(80, 80, 80));
    line(dc, 0, 60, W, 60, RGB(200, 200, 200));
    // صف التفعيل
    box(dc, 0, 61, W, 33, RGB(232, 237, 244));
    rrect(dc, 10, 71, 13, 13, 2, RGB(255, 255, 255), RGB(28, 81, 128));
    if (G.eqOn) { line(dc, 12, 77, 15, 81, RGB(20, 90, 200), 2); line(dc, 15, 81, 21, 73, RGB(20, 90, 200), 2); }
    SelectObject(dc, f9); txt(dc, L"Enable Equalizer", 28, 68, 120, 20, DT_LEFT, RGB(0, 0, 0));
    txt(dc, L"Presets", 190, 68, 66, 20, DT_RIGHT, RGB(0, 0, 0));
    std::wstring pn = L"*";
    if (G.fx && !G.progs.empty()) { int c = (int)G.fx->dispatcher(G.fx, effGetProgram, 0, 0, 0, 0); if (c >= 0 && c < (int)G.progs.size()) pn = G.progs[c]; }
    combo(dc, 262, 68, 155, 20, pn, f9);
    // أيقونة الحفظ (فلوبي) + X
    box(dc, 430, 70, 14, 14, RGB(30, 100, 200)); box(dc, 433, 70, 8, 5, RGB(255, 255, 255)); box(dc, 433, 78, 8, 6, RGB(180, 205, 245));
    line(dc, 471, 73, 482, 84, RGB(30, 100, 200), 3); line(dc, 482, 73, 471, 84, RGB(30, 100, 200), 3);
    // مقاييس dB
    SelectObject(dc, f9);
    txt(dc, L"12dB", 18, 117, 38, 18, DT_RIGHT, RGB(0, 0, 0));
    txt(dc, L"0dB", 18, 172, 38, 18, DT_RIGHT, RGB(0, 0, 0));
    txt(dc, L"-12dB", 18, 227, 38, 18, DT_RIGHT, RGB(0, 0, 0));
    tri(dc, {103, 181}, {97, 177}, {97, 185}, RGB(0, 0, 0));
    // الفيدرات
    const wchar_t* names[7] = {L"125", L"250", L"500", L"1k", L"2k", L"4k", L"8k"};
    for (int i = 0; i < 7; i++) {
        int x = bandX(i), cx = x + BOX_W / 2;
        rrect(dc, x, BOX_Y, BOX_W, BOX_H, 8, RGB(222, 222, 222), RGB(150, 150, 150));
        box(dc, cx - 2, 112, 5, 140, RGB(120, 120, 120));
        box(dc, cx - 1, 112, 3, 140, RGB(70, 70, 70));
        for (int d = -12; d <= 12; d++) {
            int y = dbToY((float)d), l = (d % 6 == 0) ? 7 : 4;
            line(dc, cx - 4 - l, y, cx - 4, y, RGB(110, 110, 110));
            line(dc, cx + 5, y, cx + 5 + l, y, RGB(110, 110, 110));
        }
        thumb(dc, cx, dbToY(G.eq.gainDb[i]));
        SelectObject(dc, f9b); txt(dc, names[i], x, 256, BOX_W, 14, DT_CENTER, RGB(40, 40, 40));
    }
    // Level
    SelectObject(dc, f9);
    txt(dc, L"0dB", 412, 122, 34, 18, DT_RIGHT, RGB(0, 0, 0));
    txt(dc, L"-24dB", 412, 218, 34, 18, DT_RIGHT, RGB(0, 0, 0));
    box(dc, 455, 118, 3, 116, RGB(70, 70, 70));
    for (int d = 0; d >= -24; d -= 2) { int y = lvToY((float)d); line(dc, 446, y, 451, y, RGB(110, 110, 110)); line(dc, 462, y, 467, y, RGB(110, 110, 110)); }
    tri(dc, {449, 124}, {443, 120}, {443, 128}, RGB(0, 0, 0));
    thumb(dc, 456, lvToY(G.levelDb));
    txt(dc, L"Level", 436, 252, 40, 14, DT_CENTER, RGB(0, 0, 0));
    // الحالة
    std::wstring st = G.status;
    if (st.empty() && !G.vstError.empty()) st = G.vstError;
    if (st.empty() && G.pcm.empty()) st = L"افتح ملف WAV (زر OPEN أو اسحبه هنا)";
    if (!st.empty()) { SelectObject(dc, f9); txt(dc, st, 8, 270, 330, 14, DT_LEFT, RGB(170, 40, 40)); }
    // الشريط السفلي
    // لوحة التأثيرات
    box(dc, 0, 284, W, BY - 284, RGB(232, 237, 244));
    line(dc, 0, 284, W, 284, RGB(200, 200, 200));
    {
        const wchar_t* fn[4] = {L"Bass Boost", L"Treble", L"Crystalliser", L"Surround"};
        float* fv[4] = {&G.fxs.bass, &G.fxs.treble, &G.fxs.crystal, &G.fxs.surround};
        for (int i = 0; i < 4; i++) {
            int tx = fxX(i), ty = fxY(i);
            SelectObject(dc, f9); txt(dc, fn[i], tx - 82, ty - 9, 80, 18, DT_RIGHT, RGB(0, 0, 0));
            box(dc, tx, ty - 2, FXW, 5, RGB(120, 120, 120)); box(dc, tx, ty - 1, FXW, 3, RGB(70, 70, 70));
            for (int k = 0; k <= 10; k++) { int xx = tx + k * FXW / 10; line(dc, xx, ty - 8, xx, ty - 5, RGB(110, 110, 110)); line(dc, xx, ty + 5, xx, ty + 8, RGB(110, 110, 110)); }
            int cx = tx + (int)lrintf(*fv[i] * FXW / 100.f);
            rrect(dc, cx - 7, ty - 11, 14, 22, 5, RGB(214, 214, 214), RGB(95, 95, 95));
            box(dc, cx - 1, ty - 9, 3, 18, RGB(44, 118, 226));
            wchar_t v[16]; swprintf(v, 16, L"%d%%", (int)lrintf(*fv[i]));
            txt(dc, v, tx + FXW + 12, ty - 9, 36, 18, DT_LEFT, RGB(40, 40, 40));
        }
    }
    gradV(dc, 0, BY, W, H - BY, RGB(150, 150, 150), RGB(105, 105, 105));
    rrect(dc, 22, BY + 4, 86, 18, 8, RGB(240, 240, 240), RGB(70, 70, 70));
    gradV(dc, 26, BY + 6, 78, 7, RGB(255, 255, 255), RGB(226, 226, 226));
    SelectObject(dc, f9); txt(dc, L"Default", 22, BY + 4, 86, 18, DT_CENTER, RGB(0, 0, 0));
    struct IB { int id; const wchar_t* t; bool on; } ib[] = {
        {H_OPEN, L"OPEN", false}, {H_PLAY, G.playing ? L"STOP" : L"PLAY", G.playing}, {H_FX, L"FX", G.fxOn}, {H_EDIT, L"EDIT", G.edWnd != 0}};
    HFONT f6 = mkFont(9, true);
    SelectObject(dc, f6);
    for (auto& b : ib) for (auto& bt : g_btn) if (bt.id == b.id) {
        int bx = bt.r.left - 3, bw = 30;
        rrect(dc, bx, bt.r.top, bw, 22, 10, b.on ? RGB(60, 130, 230) : RGB(70, 70, 70), RGB(40, 40, 40));
        txt(dc, b.t, bx, bt.r.top, bw, 22, DT_CENTER, RGB(255, 255, 255));
    }
    DeleteObject(f6);
    SelectObject(dc, f18);
    txt(dc, L"REVERB", 330, BY, 150, 28, DT_RIGHT, RGB(245, 245, 245));
    DeleteObject(f9); DeleteObject(f9b); DeleteObject(f13b); DeleteObject(f18);
    // إطار
    HBRUSH nb = (HBRUSH)GetStockObject(NULL_BRUSH); HPEN bp = CreatePen(PS_SOLID, 1, RGB(90, 100, 120));
    HGDIOBJ ob = SelectObject(dc, nb), op = SelectObject(dc, bp); Rectangle(dc, 0, 0, W, H); SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(bp);
}

// ============================================================ التحكم
static void setFlat() {
    EnterCriticalSection(&G.cs);
    for (int i = 0; i < 7; i++) G.eq.gainDb[i] = 0;
    G.levelDb = 0; G.eq.update();
    G.fxs.bass = G.fxs.treble = G.fxs.crystal = G.fxs.surround = 0; G.fxs.update();
    LeaveCriticalSection(&G.cs);
}
static void setBand(int i, float db) {
    EnterCriticalSection(&G.cs); G.eq.gainDb[i] = db; G.eq.update(); LeaveCriticalSection(&G.cs);
}
static std::wstring settingsPath() { return exeDir() + L"EQSettings.bin"; }
struct Saved { uint32_t magic; float g[7]; float lv; int32_t on; float fx[4]; };
static void saveSettings() {
    Saved s = {0x45514832, {}, G.levelDb, G.eqOn, {G.fxs.bass, G.fxs.treble, G.fxs.crystal, G.fxs.surround}};
    for (int i = 0; i < 7; i++) s.g[i] = G.eq.gainDb[i];
    FILE* f = _wfopen(settingsPath().c_str(), L"wb");
    if (f) { fwrite(&s, sizeof s, 1, f); fclose(f); G.status = L"تم حفظ الإعدادات"; } else G.status = L"ما قدرت أحفظ";
}
static void loadSettings() {
    FILE* f = _wfopen(settingsPath().c_str(), L"rb"); if (!f) return;
    Saved s; if (fread(&s, sizeof s, 1, f) == 1 && s.magic == 0x45514832) {
        G.fxs.bass = s.fx[0]; G.fxs.treble = s.fx[1]; G.fxs.crystal = s.fx[2]; G.fxs.surround = s.fx[3]; G.fxs.update();
        for (int i = 0; i < 7; i++) G.eq.gainDb[i] = s.g[i] < -12 ? -12 : (s.g[i] > 12 ? 12 : s.g[i]);
        G.levelDb = s.lv < -24 ? -24 : (s.lv > 0 ? 0 : s.lv); G.eqOn = s.on != 0; G.eq.update();
    }
    fclose(f);
}

static int hitBtn(int x, int y) {
    for (auto& b : g_btn) if (x >= b.r.left && x < b.r.right && y >= b.r.top && y < b.r.bottom) return b.id;
    return 0;
}
static int hitFader(int x, int y) {
    for (int i = 0; i < 7; i++) if (x >= bandX(i) && x < bandX(i) + BOX_W && y >= BOX_Y && y < BOX_Y + BOX_H) return i + 1;
    if (x >= 436 && x <= 478 && y >= 100 && y <= 245) return 10;
    for (int i = 0; i < 4; i++) if (x >= fxX(i) - 10 && x <= fxX(i) + FXW + 10 && y >= fxY(i) - 13 && y <= fxY(i) + 13) return 20 + i;
    return 0;
}
static float* fxPtr(int i) { float* p[4] = {&G.fxs.bass, &G.fxs.treble, &G.fxs.crystal, &G.fxs.surround}; return p[i]; }
static void setFx(int i, float v) {
    v = v < 0 ? 0 : (v > 100 ? 100 : v);
    EnterCriticalSection(&G.cs); *fxPtr(i) = v; G.fxs.update(); LeaveCriticalSection(&G.cs);
}
static void dragTo(int x, int y) {
    if (G.drag >= 20 && G.drag <= 23) { int i = G.drag - 20; setFx(i, (x - fxX(i)) * 100.f / FXW); return; }
    if (G.drag >= 1 && G.drag <= 7) setBand(G.drag - 1, yToDb(y));
    else if (G.drag == 10) { EnterCriticalSection(&G.cs); G.levelDb = yToLv(y); LeaveCriticalSection(&G.cs); }
}

static void showPresetMenu(HWND h) {
    if (!G.fx || G.progs.empty()) return;
    HMENU m = CreatePopupMenu();
    int cur = (int)G.fx->dispatcher(G.fx, effGetProgram, 0, 0, 0, 0);
    for (size_t i = 0; i < G.progs.size(); i++) AppendMenuW(m, MF_STRING | ((int)i == cur ? MF_CHECKED : 0), 1000 + i, G.progs[i].c_str());
    POINT p = {262, 88}; ClientToScreen(h, &p);
    int id = TrackPopupMenu(m, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, p.x, p.y, 0, h, 0);
    DestroyMenu(m);
    if (id >= 1000) { EnterCriticalSection(&G.cs); G.fx->dispatcher(G.fx, effSetProgram, 0, id - 1000, 0, 0); LeaveCriticalSection(&G.cs); }
}
static void showMainMenu(HWND h) {
    HMENU m = CreatePopupMenu();
    AppendMenuW(m, MF_STRING, 1, L"Open audio file...");
    AppendMenuW(m, MF_STRING, 2, G.playing ? L"Stop" : L"Play");
    AppendMenuW(m, MF_STRING, 3, L"Reverb editor");
    AppendMenuW(m, MF_SEPARATOR, 0, 0);
    AppendMenuW(m, MF_STRING, 4, L"Minimize");
    AppendMenuW(m, MF_STRING, 5, L"Exit");
    POINT p = {410, 28}; ClientToScreen(h, &p);
    int id = TrackPopupMenu(m, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, p.x, p.y, 0, h, 0);
    DestroyMenu(m);
    if (id == 1) pickFile();
    else if (id == 2) { G.playing = !G.playing; }
    else if (id == 3) openEditor();
    else if (id == 4) ShowWindow(h, SW_MINIMIZE);
    else if (id == 5) DestroyWindow(h);
}

static void click(HWND h, int id) {
    switch (id) {
    case H_CHECK: EnterCriticalSection(&G.cs); G.eqOn = !G.eqOn; LeaveCriticalSection(&G.cs); break;
    case H_PRESET: showPresetMenu(h); break;
    case H_DEV: case H_OPEN: pickFile(); break;
    case H_HELP: MessageBoxW(h, L"Graphic Equalizer + ReverbPresets64.dll (VST2)\n\nOPEN: افتح ملف WAV (أو اسحبه على النافذة)\nPLAY/STOP: تشغيل / إيقاف\nFX: تشغيل / إيقاف الـ Reverb\nEDIT: واجهة الـ Reverb نفسها\nBass Boost / Treble / Crystalliser / Surround: السلايدرات الأفقية تحت\nDouble-click على أي فيدر = يرجع 0", L"Help", MB_OK | MB_ICONINFORMATION); break;
    case H_MENU: showMainMenu(h); break;
    case H_SAVE: saveSettings(); break;
    case H_DEL: DeleteFileW(settingsPath().c_str()); setFlat(); G.status = L"تم المسح"; break;
    case H_DEFAULT: setFlat(); break;
    case H_PLAY: G.playing = !G.playing; break;
    case H_FX: if (G.fx) { EnterCriticalSection(&G.cs); G.fxOn = !G.fxOn; LeaveCriticalSection(&G.cs); } break;
    case H_EDIT: openEditor(); break;
    }
}

static LRESULT CALLBACK wndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: SetTimer(h, 1, 33, 0); DragAcceptFiles(h, TRUE); return 0;
    case WM_TIMER:
        if (G.edWnd && G.fx) G.fx->dispatcher(G.fx, effEditIdle, 0, 0, 0, 0);
        InvalidateRect(h, 0, FALSE); return 0;
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps);
        HDC mem = CreateCompatibleDC(dc); HBITMAP bm = CreateCompatibleBitmap(dc, W, H);
        HGDIOBJ old = SelectObject(mem, bm);
        paint(mem);
        BitBlt(dc, 0, 0, W, H, mem, 0, 0, SRCCOPY);
        SelectObject(mem, old); DeleteObject(bm); DeleteDC(mem);
        EndPaint(h, &ps); return 0;
    }
    case WM_NCHITTEST: {
        LRESULT r = DefWindowProcW(h, m, w, l);
        if (r != HTCLIENT) return r;
        POINT p = {GET_X_LPARAM(l), GET_Y_LPARAM(l)}; ScreenToClient(h, &p);
        if (p.y < 36 && !hitBtn(p.x, p.y)) return HTCAPTION;
        return HTCLIENT;
    }
    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(l), y = GET_Y_LPARAM(l);
        int f = hitFader(x, y);
        if (f) { G.drag = f; SetCapture(h); dragTo(x, y); return 0; }
        int b = hitBtn(x, y); if (b) click(h, b);
        return 0;
    }
    case WM_LBUTTONDBLCLK: {
        int f = hitFader(GET_X_LPARAM(l), GET_Y_LPARAM(l));
        if (f >= 1 && f <= 7) setBand(f - 1, 0);
        else if (f == 10) { EnterCriticalSection(&G.cs); G.levelDb = 0; LeaveCriticalSection(&G.cs); }
        else if (f >= 20 && f <= 23) setFx(f - 20, 0);
        return 0;
    }
    case WM_MOUSEMOVE: if (G.drag) dragTo(GET_X_LPARAM(l), GET_Y_LPARAM(l)); return 0;
    case WM_LBUTTONUP: if (G.drag) { G.drag = 0; ReleaseCapture(); } return 0;
    case WM_MOUSEWHEEL: {
        POINT p = {GET_X_LPARAM(l), GET_Y_LPARAM(l)}; ScreenToClient(h, &p);
        int f = hitFader(p.x, p.y), d = GET_WHEEL_DELTA_WPARAM(w) > 0 ? 1 : -1;
        if (f >= 1 && f <= 7) { float v = G.eq.gainDb[f - 1] + d; setBand(f - 1, v > 12 ? 12 : (v < -12 ? -12 : v)); }
        else if (f >= 20 && f <= 23) setFx(f - 20, *fxPtr(f - 20) + d * 5);
        else if (f == 10) { EnterCriticalSection(&G.cs); float v = G.levelDb + d; G.levelDb = v > 0 ? 0 : (v < -24 ? -24 : v); LeaveCriticalSection(&G.cs); }
        return 0;
    }
    case WM_DROPFILES: {
        wchar_t p[MAX_PATH];
        if (DragQueryFileW((HDROP)w, 0, p, MAX_PATH)) openAudioFile(p);
        DragFinish((HDROP)w); return 0;
    }
    case WM_KEYDOWN:
        if (w == VK_SPACE) G.playing = !G.playing;
        return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE, LPSTR, int) {
    G.inst = inst;
    InitializeCriticalSection(&G.cs);
    G.eq.setRate(48000);
    G.fxs.setRate(48000);
    loadSettings();

    // تحميل الـ DLL (بجنب البرنامج، أو من مسار في سطر الأوامر: --vst path)
    std::wstring dll = exeDir() + L"ReverbPresets64.dll", audio;
    int argc = 0; wchar_t** argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    for (int i = 1; i < argc; i++) {
        if (!wcscmp(argv[i], L"--vst") && i + 1 < argc) dll = argv[++i]; else audio = argv[i];
    }
    vstLoad(dll);

    WNDCLASSEXW c = {sizeof c};
    c.style = CS_DBLCLKS; c.lpfnWndProc = wndProc; c.hInstance = inst;
    c.hCursor = LoadCursorW(0, IDC_ARROW); c.lpszClassName = L"RevHostEQ";
    RegisterClassExW(&c);
    c.style = 0; c.lpfnWndProc = edProc; c.lpszClassName = L"RevHostEditor"; c.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    RegisterClassExW(&c);

    int sx = GetSystemMetrics(SM_CXSCREEN), sy = GetSystemMetrics(SM_CYSCREEN);
    G.wnd = CreateWindowExW(WS_EX_APPWINDOW, L"RevHostEQ", L"Graphic Equalizer", WS_POPUP | WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE,
                            (sx - W) / 2, (sy - H) / 2, W, H, 0, 0, inst, 0);
    if (!audio.empty()) openAudioFile(audio);

    MSG msg;
    while (GetMessageW(&msg, 0, 0, 0) > 0) { TranslateMessage(&msg); DispatchMessageW(&msg); }

    audioStop();
    if (G.fx) {
        if (G.edWnd) G.fx->dispatcher(G.fx, effEditClose, 0, 0, 0, 0);
        G.fx->dispatcher(G.fx, effStopProcess, 0, 0, 0, 0);
        G.fx->dispatcher(G.fx, effMainsChanged, 0, 0, 0, 0);
        G.fx->dispatcher(G.fx, 1 /*effClose*/, 0, 0, 0, 0);
    }
    return 0;
}
